#include <fstream>
#include <iostream>
#include <string>
#include "container.h"

using namespace std;

namespace nature {

	shape* InShape(ifstream& ifst);
	void OutShape(shape& sh, ofstream& ofst);
	void InTrees(trees& t, ifstream& ifst);
	void InShrubs(shrubs& s, ifstream& ifst);
	void OutTrees(trees& t, ofstream& ofst);
	void OutShrubs(shrubs& s, ofstream& ofst);

	void Init(container& c)
	{
		c.len = 0;
	}

	void Clear(container& c) {
		for (int i = 0; i < c.len; i++) {
			delete c.cont[i];
		}
		c.len = 0;
	};

	void InContainer(container& c, ifstream& ifst) {
		while (!ifst.eof()) {
			if ((c.cont[c.len] = InShape(ifst)) != 0) { c.len++; }
		}
	}

	void OutContainer(container& c, ofstream& ofst) {
		ofst << "Container contains " << c.len << " elements." << endl;
		for (int i = 0; i < c.len; i++) {
			ofst << i << ": ";
			OutShape(*(c.cont[i]), ofst);
		}
	}

	shape* InShape(ifstream& ifst)
	{
		shape* sp;
		string Type;
		getline(ifst, Type);
		int k = stoi(Type);
		//ifst >> k;
		switch (k) {
		case 1:
			sp = new shape;
			sp->k = shape::key::TREES;
			InTrees(sp->t, ifst);
			return sp;
		case 2:
			sp = new shape;
			sp->k = shape::key::SHRUBS;
			InShrubs(sp->s, ifst);
			return sp;
		default:
			return 0;
		}
	}

	void OutShape(shape& sh, ofstream& ofst) {
		switch (sh.k) {
		case shape::key::TREES:
			OutTrees(sh.t, ofst);
			break;
		case shape::key::SHRUBS:
			OutShrubs(sh.s, ofst);
			break;
		default:
			ofst << "Incorrect object!" << endl;
		}
	}

	void InShrubs(shrubs& s, ifstream& ifst)
	{
		ifst.getline(s.a, 100);
		ifst.getline(s.b, 100);
		//ifst >> s.a >> s.b;
	}

	void OutShrubs(shrubs& s, ofstream& ofst)
	{
		ofst << "It is Shrub: Month of flowering - " << s.a << " Name - " << s.b << endl;
	}

	void InTrees(trees& t, ifstream& ifst) {
		ifst.getline(t.x, 100);
		ifst.getline(t.y, 100);
		//ifst >> t.x >> t.y;
	}


	void OutTrees(trees& t, ofstream& ofst) {
		ofst << "It is Tree: Age - " << t.x << " Name - " << t.y << endl;
	}
}